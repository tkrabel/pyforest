from distutils.core import setup
setup(
  name = 'pyforest',
  packages = ['pyforest'],
  version = '0.0.0',
  license='',
  description = '',
  author = 'Tobias Krabel, Florian Wetschoreck',
  author_email = 'tobias@edaviz.com, florian@edaviz.com',
  url = 'https://github.com/tkrabel/pyforest',
  download_url = '',
  keywords = [],
  install_requires=[],
  classifiers=[],
)
